package ev2.examen;

import ev2.examen.GafasGraduadas.Posicion;
import ev2.examen.Lente.Color;
import ev2.examen.Lente.Tipo;

public class main {

	public static void main(String[] arg) {
		Optica optica = new Optica();
		
		GafasGraduadas gafaGraduada=new GafasGraduadas(Tipo.ASTIGMATISMO, 2.5, Color.VERDE, Posicion.D);
		GafasSol gafaSol = new GafasSol(Tipo.ASTIGMATISMO, 2.4, Color.VERDE, "Federico", Posicion.D);
		
		Montura montura = new Montura("Marca1", Material.METAL, "Roja");
		
		optica.addGafas(0, gafaGraduada);
		optica.addGafas(1, gafaSol);
		
		Proveedor proveedor1 = new Proveedor("cif1", "nombre1", "tel1");
		
		optica.cuantasGafas();
		
		optica.dimeTipoLente(gafaSol);
		
		optica.delGafas(gafaSol);
		
		optica.damePrecioGafa(gafaSol);
		
		optica.gafasByProveedor();
		
		optica.costeGafasByTipo();
		
		optica.generaFichero();
		
		optica.cargaFichero();
	}
}
