package ev2.examen;

public class Proveedor {
	private int cif;
	private String nombre;
	private String telefono;
	
	public Proveedor(int cif, String nombre, String telefono) {
		this.cif = cif;
		this.nombre = nombre;
		this.telefono = telefono;
	}

	public int getCif() {
		return cif;
	}

	public void setCif(int cif) {
		this.cif = cif;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	@Override
	public String toString() {
		return "Proveedor [cif=" + cif + ", nombre=" + nombre + ", telefono=" + telefono + "]";
	}
}
