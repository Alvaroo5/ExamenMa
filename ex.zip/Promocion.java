package ev2.examen;

public interface Promocion {
	public void aplicaDescuento();
}
