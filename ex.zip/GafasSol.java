package ev2.examen;

import ev2.examen.GafasGraduadas.Posicion;

public class GafasSol extends Lente implements Promocion{

	private String nombreProveedor;
	private enum Posicion{D, I};
	private Posicion posicion;
	
	
	
	public GafasSol(Tipo tipo, double gradoCorreccion, Color color, String nombreProveedor, Posicion posicion) {
		super(tipo, gradoCorreccion, color);
		this.nombreProveedor = nombreProveedor;
		this.posicion = posicion;
	}

	@Override
	public void aplicaDescuento() {
		// TODO Auto-generated method stub
		
	}
	
}
