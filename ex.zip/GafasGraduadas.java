package ev2.examen;

public class GafasGraduadas extends Lente{
	
	public enum Posicion{D, I};
	private Posicion posicion;
	
	public GafasGraduadas(Tipo tipo, double gradoCorreccion, Color color, Posicion posicion) {
		super(tipo, gradoCorreccion, color);
		this.posicion = posicion;
	}
	
	

}
