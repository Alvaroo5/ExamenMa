package ev2.examen;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Optica {
	private Map<Integer, String> contenido = new HashMap<>();
	protected List<Gafa> contenido_GafasG;
	protected List<Gafa> contenido_GafasS;
	
	//Constructor de Optica
	public Optica() {
		this.contenido = new HashMap<Integer, String>();
		this.contenido_GafasG= new ArrayList<Gafa>();
		this.contenido_GafasS= new ArrayList<Gafa>();
	}
	
	//Metodo en el que añadimos gafas 
	public void addGafas(int id, String gafa) {
		contenido.put(id, gafa);
	}
	
	//Metodo en el que contamos la cantidad de gafas
	public int cuantasGafas() {
		return contenido.size();
	}
	
	//Metodo en el que nos dice si es graduada o no
	public void dimeTipoLente(Lente lente) {
		if(lente instanceof GafasGraduadas) {
			System.out.println("La lente es graduada");
		}else {
			System.out.println("La lente no es graduada");
		}
	}
	
	//Metodo para eliminar gafas
	public void delGafas(Gafa gafa) {
		contenido.remove(gafa);
	}
	
	//Metodo para saber el precio de la gafa
	public double damePrecioGafa(Gafa gafa) throws Exception {
		double precioConDescuento = gafa.getPrecioVenta();
		gafa.aplicaDescuento();
		if(precioConDescuento < gafa.getCoste()) {
			throw new Exception("Venta a perdidas");
		}
		return precioConDescuento;
	}
	
	public void gafasByProveedor() {
		
	}
	
	//Metodo en el que nos devuelve el coste de un tipo de gafa
	public void costeGafasByTipo(String tipo) {
		double coste = 0;
		for(String gafa : contenido.values()) {
			if(gafa.getTipo().equals(tipo)) {
				coste+=gafa.getCoste();
			}
		}
		System.out.println("El coste de la gafa tipo "+tipo+" es de "+coste);
	}
	
	//Metodo en el que generamos el fichero
	public void generaFichero() {
		try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("gafas.dat"))){
			oos.writeObject(new ArrayList<>(contenido.values()));
			System.out.println("Generado correctamente el fichero");
		}catch (IOException e){
			System.out.println("Error al generar el fichero");
		}
	}
	
	//Metodo en el que cargamos el fichero
	public void cargaFichero() {
		try(ObjectInputStream ois = new ObjectInputStream(new FileInputStream("gafas.dat"))){
			List<Gafa> gafasCarga = (List<Gafa>) ois.readObject();
			contenido.clear();
			for (Gafa gafa : gafasCarga) {
				contenido.put(gafa.getId(), gafa);
			}
			System.out.println("Gafas cargadas correctamente");
		}catch(IOException | ClassNotFoundException e) {
			System.out.println("Error al cargar las gafas");
		}
	}
}
