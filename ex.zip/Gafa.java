package ev2.examen;

import java.io.Serializable;

public class Gafa implements Promocion, Serializable{
	private static final long serialVersionUID = 1L;
	
	private int id;
	private Montura montura;
	private Lente lenteDerecha;
	private Lente lenteIzquierda;
	private double coste;
	private double precioVenta;
	private static int contadorGafas = 0;
	
	//Constructor de Gafas
	public Gafa(int id, Montura montura, Lente lenteDerecha, Lente lenteIzquierda, double coste, double precioVenta) {
		this.id = id;
		this.montura = montura;
		this.lenteDerecha = lenteDerecha;
		this.lenteIzquierda = lenteIzquierda;
		this.coste = coste;
		this.precioVenta = precioVenta;
	}
	
	//Metodos Getters y Setters
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Montura getMontura() {
		return montura;
	}

	public void setMontura(Montura montura) {
		this.montura = montura;
	}

	public Lente getLenteDerecha() {
		return lenteDerecha;
	}

	public void setLenteDerecha(Lente lenteDerecha) {
		this.lenteDerecha = lenteDerecha;
	}

	public Lente getLenteIzquierda() {
		return lenteIzquierda;
	}

	public void setLenteIzquierda(Lente lenteIzquierda) {
		this.lenteIzquierda = lenteIzquierda;
	}

	public double getCoste() {
		return coste;
	}

	public void setCoste(double coste) {
		this.coste = coste;
	}

	public double getPrecioVenta() {
		return precioVenta;
	}

	public void setPrecioVenta(double precioVenta) {
		this.precioVenta = precioVenta;
	}

	public static int getContadorGafas() {
		return contadorGafas;
	}

	public static void setContadorGafas(int contadorGafas) {
		Gafa.contadorGafas = contadorGafas;
	}

	@Override
	public String toString() {
		return "Gafa [id=" + id + ", montura=" + montura + ", lenteDerecha=" + lenteDerecha + ", lenteIzquierda="
				+ lenteIzquierda + ", coste=" + coste + ", precioVenta=" + precioVenta + "]";
	}

	//Interfaz implementado
	@Override
	public void aplicaDescuento() {
		// TODO Auto-generated method stub
		
	}
}
