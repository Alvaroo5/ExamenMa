package ev2.examen;

public class Lente {
	protected enum Tipo{ASTIGMATISMO, MIOPIA, HIPERMETROPIA};
	private Tipo tipo;
	private double gradoCorreccion;
	protected enum Color{VERDE, MARRON, GRIS};
	private Color color;
	
	//Constructor de Lente
	public Lente(Tipo tipo, double gradoCorreccion, Color color) {
		this.tipo = tipo;
		this.gradoCorreccion = gradoCorreccion;
		this.color = color;
	}

	//Metodos Getters y Setters
	public Tipo getTipo() {
		return tipo;
	}

	public void setTipo(Tipo tipo) {
		this.tipo = tipo;
	}

	public double getGradoCorreccion() {
		return gradoCorreccion;
	}

	public void setGradoCorreccion(double gradoCorreccion) {
		this.gradoCorreccion = gradoCorreccion;
	}

	public Color getColor() {
		return color;
	}

	public void setColor(Color color) {
		this.color = color;
	}

	@Override
	public String toString() {
		return "Lente [tipo=" + tipo + ", gradoCorreccion=" + gradoCorreccion + ", color=" + color + "]";
	}
	
}
