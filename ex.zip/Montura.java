package ev2.examen;

public class Montura {
	private String marca;
	private enum Material{PASTA, METAL};
	private Material material;
	private String color;
	
	//Constructor de Montura
	public Montura(String marca, Material material, String color) {
		this.marca = marca;
		this.material = material;
		this.color = color;
	}

	//Metodos Getters y Setters
	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public Material getMaterial() {
		return material;
	}

	public void setMaterial(Material material) {
		this.material = material;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	@Override
	public String toString() {
		return "Montura [marca=" + marca + ", material=" + material + ", color=" + color + "]";
	}
}
